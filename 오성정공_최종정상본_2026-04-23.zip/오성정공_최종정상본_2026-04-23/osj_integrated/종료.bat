@echo off
taskkill /F /IM pythonw.exe
taskkill /F /IM python.exe
timeout /t 1 > nul
exit