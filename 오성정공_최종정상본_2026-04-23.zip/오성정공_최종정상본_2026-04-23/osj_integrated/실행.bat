@echo off
cd /d "%~dp0"
start "" pythonw launch.pyw
exit