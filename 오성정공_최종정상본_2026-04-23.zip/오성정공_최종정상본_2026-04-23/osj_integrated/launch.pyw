# -*- coding: utf-8 -*-
"""
오성정공 금형기반 스마트 생산품질 관리시스템
실행 엔진 v2.4 (launch.pyw)

[창 최대화 방식]
Chrome --app 모드에서 --start-maximized 플래그는 공식적으로 무시됨.
대신 브라우저 프로세스 시작 후 Windows API(ctypes.windll.user32)로
해당 창 핸들을 직접 찾아 SW_MAXIMIZE 명령을 전송하여 강제 최대화.
"""

import sys
import os
import threading
import time
import webbrowser
import socket
import subprocess

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

_env_site = os.path.join(BASE_DIR, '_env', 'Lib', 'site-packages')
if os.path.isdir(_env_site):
    sys.path.insert(0, _env_site)

PORT     = 5000
HOST     = '127.0.0.1'
URL      = f'http://{HOST}:{PORT}/'
PID_FILE = os.path.join(BASE_DIR, '_runtime', 'server.pid')

SW_MAXIMIZE  = 3
SW_SHOWMAXIMIZED = 3


# ── PID 파일 ─────────────────────────────────────────────────
def _write_pid():
    os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

def _clear_pid():
    try:
        os.remove(PID_FILE)
    except Exception:
        pass


# ── 포트 확인 ─────────────────────────────────────────────────
def _port_in_use():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((HOST, PORT)) == 0


# ── Flask ────────────────────────────────────────────────────
def _run_flask():
    from app import app as flask_app
    flask_app.run(host=HOST, port=PORT, debug=False, use_reloader=False)


# ── Windows API로 창 최대화 ───────────────────────────────────
def _maximize_window_by_title(title_fragment, timeout=15):
    """
    title_fragment를 제목에 포함하는 창을 찾아 최대화.
    Windows API 직접 호출 (ctypes).
    """
    try:
        import ctypes
        import ctypes.wintypes

        user32 = ctypes.windll.user32

        found = []

        # EnumWindows 콜백: 창 제목에 URL 또는 앱 이름 포함 여부 확인
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool,
                                             ctypes.wintypes.HWND,
                                             ctypes.wintypes.LPARAM)

        def callback(hwnd, lParam):
            if user32.IsWindowVisible(hwnd):
                length = user32.GetWindowTextLengthW(hwnd)
                if length > 0:
                    buf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buf, length + 1)
                    title = buf.value
                    for frag in title_fragment:
                        if frag.lower() in title.lower():
                            found.append(hwnd)
                            break
            return True

        proc = EnumWindowsProc(callback)
        deadline = time.time() + timeout

        while time.time() < deadline:
            found.clear()
            user32.EnumWindows(proc, 0)
            if found:
                hwnd = found[0]
                # ShowWindow SW_MAXIMIZE
                user32.ShowWindow(hwnd, SW_MAXIMIZE)
                # 포커스도 올림
                user32.SetForegroundWindow(hwnd)
                return True
            time.sleep(0.5)

    except Exception:
        pass
    return False


# ── 앱 모드 브라우저 실행 ────────────────────────────────────
def _open_app_browser():
    candidates = [
        r'C:\Program Files\Google\Chrome\Application\chrome.exe',
        r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
        os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe'),
        r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
        r'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
        os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe'),
    ]

    # --start-maximized는 --app 모드에서 무시됨(Chrome 공식 버그)
    # → 창 크기를 화면 전체로 지정하고 사후에 ctypes로 최대화 강제 적용
    app_flags = [
        f'--app={URL}',
        '--window-size=1920,1080',   # 초기 크기 (최대화 전 기본값)
        '--window-position=0,0',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-extensions',
    ]

    launched = False
    browser_type = None

    for exe in candidates:
        if os.path.isfile(exe):
            try:
                subprocess.Popen(
                    [exe] + app_flags,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                launched = True
                browser_type = 'chrome' if 'chrome' in exe.lower() else 'edge'
                break
            except Exception:
                continue

    if not launched:
        webbrowser.open(URL)
        return

    # 브라우저 창이 뜨길 기다렸다가 Windows API로 최대화
    # 창 제목 후보: URL 도메인, 시스템 이름, 브라우저 종류
    title_fragments = ['오성정공', '127.0.0.1', 'localhost', 'Chrome', 'Edge']
    threading.Thread(
        target=_maximize_window_by_title,
        args=(title_fragments,),
        daemon=True
    ).start()


# ── Flask 준비 대기 후 브라우저 실행 ─────────────────────────
def _open_when_ready():
    for _ in range(40):
        time.sleep(0.5)
        if _port_in_use():
            _open_app_browser()
            return
    _open_app_browser()


# ── 메인 ──────────────────────────────────────────────────────
def main():
    if _port_in_use():
        _open_app_browser()
        return

    _write_pid()

    flask_thread   = threading.Thread(target=_run_flask,       daemon=True)
    browser_thread = threading.Thread(target=_open_when_ready, daemon=True)
    flask_thread.start()
    browser_thread.start()

    try:
        flask_thread.join()
    finally:
        _clear_pid()


if __name__ == '__main__':
    main()
